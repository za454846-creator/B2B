import React, { useState } from "react";
import { Helmet } from "react-helmet-async";
import CTASection from "../components/Home_components/CTASection";
import FaqComponent from '../components/Home_components/FaqComponent';
import "../assets/css/pricing.css";

/*
  CONTENT UPDATE IN THIS PASS:
  - New banner heading/paragraph, with a second CTA button added
    (banner only had one "Learn More" button before — now has
    "See Full Feature Breakdown" (scrolls to the plans grid) and
    "Talk to Sales" (links to /contact-us)).
  - New pricing section heading/subtitle ("Two Ways to Pay On The
    Same Platform").
  - All 3 plans updated: Starter and Enterprise stay at the same
    price shape, Growth renamed from "Professional" with a new yearly
    price display showing both the annual total AND the effective
    monthly rate (e.g. "$1,490/year ($124/mo)"), plus a per-plan
    note line under the price for all three plans (previously only
    Enterprise had a note).
  - FIXED A CURRENCY MISMATCH: the price was displayed with "₨"
    (Pakistani Rupee) throughout, but the new closing CTA note
    explicitly says "Prices shown in USD." Switched the displayed
    symbol to "$" and updated the JSON-LD `priceCurrency` from "PKR"
    to "USD" to match.
  - FAQ section replaced with "Pricing Questions Answered Plainly"
    and 5 new pricing-specific questions.
  - Closing CTA replaced with "Your Plan Should Cost Less Than One
    Bid You Win" and new button/note text.
  - NOTE (not fixed, needs your input): kept the existing
    `.pricing_card` class name as-is per your file. Earlier I'd
    flagged that this class name collides with home.css's own
    `.pricing_card` (different design) used elsewhere — if you're
    still seeing style bleed between this page and other pricing
    cards on the site, let me know and I can rename this page's class
    to something distinct (e.g. `.pricing-plan-card`) again.
*/

const PAGE_URL = 'https://www.example.com/pricing';
const PAGE_TITLE = 'Pricing Plans | Bid Connectors';
const PAGE_DESCRIPTION =
  'Simple, transparent pricing for Bid Connectors. Choose a flexible monthly or yearly plan for individuals, growing businesses, or enterprises.';

const plans = [
  {
    name: "Starter",
    desc: "For a single estimator testing the platform",
    monthlyPrice: "0",
    yearlyPrice: "0",
    yearlyPerMonth: null,
    priceNote: "Free indefinitely. No trial clock, no credit card.",
    btnText: "Start Free",
    btnClass: "btn-outline",
    popular: false,
    features: [
      { text: "30 project views/month", active: true },
      { text: "Basic trade & location filters", active: true },
      { text: "Weekly email alerts", active: true },
      { text: "Bid package assembly", active: false },
      { text: "Trade partner directory", active: false },
    ],
  },
  {
    name: "Growth",
    desc: "For active subcontractors and small GCs",
    monthlyPrice: "149",
    yearlyPrice: "1,490",
    yearlyPerMonth: "124",
    priceNote: "Save $298/year (about 17%) versus paying monthly.",
    btnText: "Get Started",
    btnClass: "btn-card",
    popular: true,
    features: [
      { text: "Unlimited project views", active: true },
      { text: "Advanced filters + saved searches", active: true },
      { text: "Bid package assembly", active: true },
      { text: "Takeoff Studio (300 pages/mo)", active: true },
      { text: "Trade partner directory access", active: true },
      { text: "Bid readiness check", active: true },
    ],
  },
  {
    name: "Enterprise",
    desc: "For general contractors and multi-office firms",
    monthlyPrice: null,
    yearlyPrice: null,
    yearlyPerMonth: null,
    priceNote: "Priced by team size and usage. Talk to sales.",
    btnText: "Contact Sales",
    btnClass: "btn-outline",
    popular: false,
    features: [
      { text: "Everything in Growth", active: true },
      { text: "Unlimited takeoff pages", active: true },
      { text: "Team seats (10+)", active: true },
      { text: "API access & integrations", active: true },
      { text: "Dedicated account manager", active: true },
      { text: "Custom reporting", active: true },
    ],
  },
];

const faqs = [
  {
    question: "Why is Starter free, and what's the catch?",
    answer: "There isn't one. Starter is capped at 30 project views a month and doesn't include bid package assembly or the trade partner directory, so it's genuinely limited, not a disguised trial. Plenty of solo estimators use it as their only plan.",
  },
  {
    question: "What happens if I go over my Takeoff Studio page limit?",
    answer: "Growth accounts include 300 takeoff pages a month. Extra pages are billed at $0.35 each for the rest of that cycle, or you can move to Enterprise for unlimited pages if that becomes a regular pattern.",
  },
  {
    question: "Is the yearly plan actually cheaper, or just deferred billing?",
    answer: "It's a real discount, not just prepayment. Growth billed yearly works out to $124 a month instead of $149, close to two months free compared with paying monthly all year.",
  },
  {
    question: "Can I switch from monthly to yearly in the middle of a subscription?",
    answer: "Yes. Switching applies the yearly rate starting on your next billing date and prorates any remaining time on your current monthly cycle, so you're not charged twice for the same period.",
  },
  {
    question: "Do nonprofits, schools, or government agencies get a different rate?",
    answer: "There's no published nonprofit or agency discount today, but if you're a public agency evaluating the platform for internal use rather than bidding, reach out and we'll see what makes sense.",
  },
];

const pricingSchema = {
  '@context': 'https://schema.org',
  '@type': 'Product',
  name: 'Bid Connectors Subscription Plans',
  description: PAGE_DESCRIPTION,
  offers: plans
    .filter((p) => p.monthlyPrice)
    .map((p) => ({
      '@type': 'Offer',
      name: p.name,
      description: p.desc,
      price: p.monthlyPrice.replace(/,/g, ''),
      priceCurrency: 'USD',
      url: PAGE_URL,
    })),
};

function Pricing() {
  const [isYearly, setIsYearly] = useState(false);

  return (
    <>
      <Helmet>
        <title>{PAGE_TITLE}</title>
        <meta name="description" content={PAGE_DESCRIPTION} />
        <link rel="canonical" href={PAGE_URL} />

        {/* Open Graph */}
        <meta property="og:type" content="website" />
        <meta property="og:title" content={PAGE_TITLE} />
        <meta property="og:description" content={PAGE_DESCRIPTION} />
        <meta property="og:url" content={PAGE_URL} />

        {/* Twitter Card */}
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:title" content={PAGE_TITLE} />
        <meta name="twitter:description" content={PAGE_DESCRIPTION} />

        {/* Structured data: pricing plans */}
        <script type="application/ld+json">
          {JSON.stringify(pricingSchema)}
        </script>
      </Helmet>

      <main>
        {/* ================= BANNER ================= */}
        <section className="pricing-banner" aria-label="Page introduction">
          <div className="container">
            <div className="banner-content">
              <h1>
                Pay Only for the Bids <span>You're Actually Chasing</span>
              </h1>

              <p>
                No lead quotas, no per-project fees, and no charge for
                browsing. Every plan scales with how much of the platform
                your team actually uses, not how many projects happen to
                exist in your area that month.
              </p>

              <div className="banner-cta-group">
                <a href="https://bidconnectors.com/bidconnectors/register" className="banner-btn" target="_blank" rel="noopener noreferrer">See Full Feature Breakdown</a>
                <a href="https://bidconnectors.com/bidconnectors/register" className="banner-btn banner-btn-outline" target="_blank" rel="noopener noreferrer">Talk to Sales</a>
              </div>
            </div>
          </div>
        </section>

        {/* ================= PRICING ================= */}
        <section className="pricing-section section" id="plans" aria-label="Pricing plans">
          <div className="container">

            <div className="pricing-top">

              <h2 className="pricing_heading">
                Two Ways to Pay On The Same Platform
              </h2>

              <p className="pricing-sub">
                Pay month-to-month for flexibility, or pay yearly and knock
                about two months off the annual cost. Nothing about the
                product changes either way.
              </p>

              {/* ================= TOGGLE ================= */}
              <div className="toggle-wrap" role="group" aria-label="Billing period">

                <button
                  type="button"
                  className={`toggle-label ${!isYearly ? "active" : ""}`}
                  onClick={() => setIsYearly(false)}
                  aria-pressed={!isYearly}
                >
                  <span className="toggle-icon" aria-hidden="true">📅</span>
                  Monthly
                </button>

                <label className="toggle-switch">
                  <span className="visually-hidden">Toggle yearly billing</span>
                  <input
                    type="checkbox"
                    checked={isYearly}
                    onChange={(e) => setIsYearly(e.target.checked)}
                  />
                  <div className="toggle-track"></div>
                  <div className="toggle-thumb"></div>
                </label>

                <button
                  type="button"
                  className={`toggle-label ${isYearly ? "active" : ""}`}
                  onClick={() => setIsYearly(true)}
                  aria-pressed={isYearly}
                >
                  <span className="toggle-icon" aria-hidden="true">🏆</span>
                  Yearly
                </button>

              </div>
            </div>

            {/* ================= CARDS ================= */}
            <div className="pricing-grid">
              {plans.map((plan) => (
                <div
                  key={plan.name}
                  className={`pricing_card ${plan.popular ? "popular" : ""}`}
                >

                  {plan.popular && (
                    <div className="popular-badge">
                      MOST POPULAR
                    </div>
                  )}

                  <h3>{plan.name}</h3>

                  <p className="card-desc">{plan.desc}</p>

                  {/* PRICE */}
                  <div className="card-price">
                    {plan.monthlyPrice ? (
                      <>
                        <div className="price-amount">
                          ${isYearly ? plan.yearlyPrice : plan.monthlyPrice}
                        </div>
                        <span className="price-period">
                          {isYearly ? "/year" : "/month"}
                          {isYearly && plan.yearlyPerMonth && ` ($${plan.yearlyPerMonth}/mo)`}
                        </span>
                      </>
                    ) : (
                      <div className="price-custom">Custom</div>
                    )}
                  </div>

                  {plan.priceNote && (
                    <p className="price-note">{plan.priceNote}</p>
                  )}

                  <button className={`btn-card ${plan.btnClass}`} type="button">
                    {plan.btnText}
                  </button>

                  <div className="divider"></div>

                  <ul className="features-list">
                    {plan.features.map((f, i) => (
                      <li key={i} className={!f.active ? "disabled" : ""}>
                        <span className="check" aria-hidden="true">
                          {f.active ? '✓' : '✕'}
                        </span>
                        {f.text}
                        <span className="visually-hidden">
                          {f.active ? ' (included)' : ' (not included)'}
                        </span>
                      </li>
                    ))}
                  </ul>

                </div>
              ))}
            </div>

          </div>
        </section>

        {/* ================= FAQ ================= */}
        <FaqComponent
          title="Pricing Questions"
          highlight="Answered Plainly"
          description="Straightforward answers about billing, limits, and switching plans."
          faqs={faqs}
        />

        <CTASection
          titleLine1="Your Plan Should Cost Less"
          titleHighlight="Than One Bid You Win"
          subText="Start free, upgrade when Starter's limits start getting in your way and not before."
          primaryBtnText="Start Free"
        primaryBtnLink="https://bidconnectors.com/bidconnectors/register"
  primaryBtnNewTab={true}
  secondaryBtnText="Talk to Sales"
  secondaryBtnLink="https://bidconnectors.com/bidconnectors/register"
  secondaryBtnNewTab={true}
  noteText="No credit card · Free forever plan · Cancel anytime"
        />
      </main>

      <style>{`
        .visually-hidden {
          position: absolute;
          width: 1px;
          height: 1px;
          padding: 0;
          margin: -1px;
          overflow: hidden;
          clip: rect(0, 0, 0, 0);
          white-space: nowrap;
          border: 0;
        }
        .toggle-label {
          background: none;
          border: none;
          font: inherit;
          cursor: pointer;
        }
        .banner-cta-group {
          display: flex;
          gap: 16px;
          justify-content: center;
          flex-wrap: wrap;
        }
        .banner-btn-outline {
          background: transparent;
          border: 1px solid var(--color-orange, #E86129);
          color: var(--color-orange, #E86129);
        }
        .price-note {
          font-size: 12px;
          color: #888;
          margin-top: 8px;
          line-height: 1.4;
        }
      `}</style>
    </>
  );
}

export default Pricing;