// ContactUs.jsx - Clean & Professional Contact Component
import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';

/*
  SEO FIXES (kept from previous pass):
  - <Helmet> with title, meta description, canonical URL, Open Graph
    tags, and JSON-LD ContactPage + Organization structured data.
  - Heading hierarchy fixed (h1 -> h2 -> h2 -> h2 -> h2).
  - Decorative icons marked aria-hidden, visually-hidden <label>s added
    per form field, <main> landmark + section aria-labels.

  UPDATED IN THIS PASS:
  - Meta title/description replaced with the new copy.
  - Banner heading/paragraph replaced with the new copy ("Talk to a
    Person, Not a Bot!").
  - Added a "Schedule a Free Call" button under the banner paragraph
    (the new copy says "Click the button below..." so a button needed
    to exist) — it scroll-links to the message form further down the
    page (id="contact-form") since no external scheduling link was
    provided. If you have a real scheduling tool (Calendly, etc.),
    swap the href for that link instead.
*/

const PAGE_URL = '/contact-us';
const PAGE_TITLE = 'Contact Bid Connectors Experts';
const PAGE_DESCRIPTION =
  'Bid Connectors team is available 24/7 to support customers, answer their questions, and help them find the best trade-specific projects. Fill out the form and get insights from experts.';

const contactSchema = {
  '@context': 'https://schema.org',
  '@type': 'ContactPage',
  name: PAGE_TITLE,
  url: PAGE_URL,
  about: {
    '@type': 'Organization',
    name: 'Bid Connectors',
    contactPoint: [
      {
        '@type': 'ContactPoint',
        telephone: '+1-555-123-4567',
        contactType: 'customer service',
        email: 'hello@buildpulse.com',
      },
    ],
    address: {
      '@type': 'PostalAddress',
      streetAddress: '123 Construction Avenue',
      addressLocality: 'New York',
      addressRegion: 'NY',
      postalCode: '10001',
      addressCountry: 'US',
    },
  },
};

const ContactUs = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    setTimeout(() => {
      setSubmitted(true);
      setLoading(false);
      setFormData({ name: '', email: '', phone: '', message: '' });
      setTimeout(() => setSubmitted(false), 3000);
    }, 1000);
  };

  return (
    <>
      <Helmet>
        <title>{PAGE_TITLE}</title>
        <meta name="description" content={PAGE_DESCRIPTION} />
        <link rel="canonical" href={PAGE_URL} />

        {/* Open Graph */}
        <meta property="og:type" content="website" />
        <meta property="og:title" content={PAGE_TITLE} />
        <meta property="og:description" content={PAGE_DESCRIPTION} />
        <meta property="og:url" content={PAGE_URL} />

        {/* Twitter Card */}
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:title" content={PAGE_TITLE} />
        <meta name="twitter:description" content={PAGE_DESCRIPTION} />

        {/* Structured data: contact info */}
        <script type="application/ld+json">
          {JSON.stringify(contactSchema)}
        </script>
      </Helmet>

      <style>{`
        :root {
          --color-black: #111111;
          --color-dark: #161211;
          --color-orange: #E86129;
          --color-orange-hover: #CF4525;
          --color-light: #E4E4E7;
        }

        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        .contact-page {
          font-family: 'Inter', sans-serif;
        }

        .container {
          max-width: 1250px;
          margin: 0 auto;
          padding: 0 16px;
        }

        @keyframes contactFadeUp {
          from { opacity: 0; transform: translateY(24px); }
          to { opacity: 1; transform: translateY(0); }
        }

        @media (prefers-reduced-motion: reduce) {
          .contact-page * {
            animation: none !important;
            transition: none !important;
          }
        }

        /* Banner Section */
        .banner {
          padding: 80px 0;
          text-align: center;
          animation: contactFadeUp 0.6s ease both;
        }

        .banner h1 {
          font-weight: 800;
          margin-bottom: 16px;
        }

        .banner h1 span {
          color: var(--color-orange);
        }

        .banner p {
          font-size: 18px;
          color: #9CA3AF;
          max-width: 700px;
          margin: 0 auto 28px;
        }

        .banner-btn {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: var(--color-orange);
          color: #fff;
          border: none;
          padding: 13px 28px;
          border-radius: 8px;
          font-size: 15px;
          font-weight: 600;
          cursor: pointer;
          text-decoration: none;
          transition: all 0.3s ease;
        }

        .banner-btn:hover {
          background: var(--color-orange-hover);
          transform: translateY(-2px);
        }

        /* Contact Section */
        .contact-section {
          padding: 80px 0;
        }

        .contact-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 48px;
        }

        /* Cards — intentionally dark in both site themes, like the footer */
        .cards-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 24px;
          margin-bottom: 48px;
        }

        .contact-card {
          background: var(--color-dark);
          padding: 32px 24px;
          border-radius: 16px;
          text-align: center;
          transition: all 0.3s ease;
          box-shadow: 0 10px 35px 0px rgba(207, 69, 37, 0.3);
          animation: contactFadeUp 0.6s ease both;
        }

        .contact-card:hover {
          transform: translateY(-4px);
          box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.3);
        }

        .contact-card i {
          font-size: 40px;
          color: var(--color-orange);
          margin-bottom: 16px;
          display: inline-block;
          transition: transform 0.3s ease;
        }

        .contact-card:hover i {
          transform: scale(1.1) rotate(-6deg);
        }

        .contact-card h2 {
          font-size: 20px;
          font-weight: 700;
          color: #fff;
          margin-bottom: 12px;
        }

        .contact-card p {
          font-size: 14px;
          color: var(--color-light);
          line-height: 1.6;
        }

        .contact-card a {
          color: var(--color-orange);
          text-decoration: none;
          font-size: 14px;
          font-weight: 500;
        }

        /* Form — also intentionally dark card in both themes */
        .form-wrapper {
          background: var(--color-dark);
          padding: 40px;
          border-radius: 16px;
          box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.2);
          animation: contactFadeUp 0.6s ease 0.1s both;
        }

        .form-wrapper h2 {
          font-size: 28px;
          font-weight: 700;
          color: #ffffff;
          margin-bottom: 8px;
        }

        .form-wrapper p {
          color: var(--color-light);
          margin-bottom: 32px;
        }

        .form-group {
          margin-bottom: 24px;
        }

        .form-group input,
        .form-group textarea {
          width: 100%;
          padding: 14px 16px;
          border-bottom: 1px solid #3a3a3a;
          border-radius: 0;
          background: transparent;
          font-size: 14px;
          font-family: 'Inter', sans-serif;
          transition: all 0.3s ease;
          border-top: 0;
          border-left: 0;
          border-right: 0;
          color: #ffffff;
        }

        .form-group input::placeholder,
        .form-group textarea::placeholder {
          color: #9CA3AF;
        }

        .form-group input:focus,
        .form-group textarea:focus {
          outline: none;
          border-color: var(--color-orange);
          box-shadow: 0 3px 0 0 rgba(232, 97, 41, 0.3);
        }

        .form-group textarea {
          resize: vertical;
          min-height: 120px;
        }

        .submit-btn {
          width: 100%;
          background: var(--color-orange);
          color: white;
          padding: 14px;
          border: none;
          border-radius: 12px;
          font-size: 16px;
          font-weight: 600;
          font-family: 'Inter', sans-serif;
          cursor: pointer;
          transition: all 0.3s ease;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
        }

        .submit-btn:hover:not(:disabled) {
          background: var(--color-orange-hover);
          transform: translateY(-2px);
        }

        .submit-btn:disabled {
          opacity: 0.7;
          cursor: not-allowed;
        }

        .spinner {
          width: 18px;
          height: 18px;
          border: 2px solid white;
          border-top-color: transparent;
          border-radius: 50%;
          animation: spin 0.6s linear infinite;
        }

        @keyframes spin {
          to { transform: rotate(360deg); }
        }

        .success-message {
          background: #F0FDF4;
          border: 1px solid #BBF7D0;
          border-radius: 12px;
          padding: 20px;
          text-align: center;
          animation: contactFadeUp 0.4s ease both;
        }

        .success-message i {
          font-size: 48px;
          color: #22C55E;
          margin-bottom: 12px;
        }

        .success-message h3 {
          color: #166534;
          margin-bottom: 4px;
        }

        .success-message p {
          color: #166534;
        }

        /* Map */
        .map-wrapper {
          background: white;
          border-radius: 16px;
          overflow: hidden;
          box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.15);
          height: 100%;
          min-height: 500px;
          animation: contactFadeUp 0.6s ease 0.2s both;
        }

        .map-wrapper iframe {
          width: 100%;
          height: 100%;
          border: none;
        }

        /* Responsive */
        @media (max-width: 1024px) {
          .banner h1 { font-size: 48px; }
        }

        @media (max-width: 768px) {
          .banner { padding: 60px 0; }
          .banner h1 { font-size: 36px; }
          .banner p { font-size: 16px; }
          .contact-section { padding: 60px 0; }
          .contact-grid { grid-template-columns: 1fr; gap: 32px; }
          .cards-grid { grid-template-columns: 1fr; gap: 16px; margin-bottom: 32px; }
          .form-wrapper { padding: 32px; }
          .form-wrapper h2 { font-size: 24px; }
        }

        @media (max-width: 480px) {
          .banner h1 { font-size: 28px; }
          .form-wrapper { padding: 24px; }
        }

        .visually-hidden {
          position: absolute;
          width: 1px;
          height: 1px;
          padding: 0;
          margin: -1px;
          overflow: hidden;
          clip: rect(0, 0, 0, 0);
          white-space: nowrap;
          border: 0;
        }
      `}</style>

      <main className="contact-page">
        {/* Banner */}
        <div className="banner" aria-label="Page introduction">
          <div className="container">
            <h1>Talk to a Person, <span>Not a Bot!</span></h1>
            <p>
              Whether you're comparing plans, checking coverage in your
              service area, or just want to see the platform before setting
              up an account, someone on our team can walk you through it.
              Click the button below and schedule a free call!
            </p>
            <a href="https://bidconnectors.com/bidconnectors/register" className="banner-btn" target="_blank" rel>
              Browse Open Projects <i className="bi bi-arrow-right" aria-hidden="true"></i>
            </a>
          </div>
        </div>

        {/* Contact Section */}
        <div className="contact-section" aria-label="Contact information and form">
          <div className="container">
            {/* 3 Cards */}
            <div className="cards-grid">
              <div className="contact-card">
                <i className="bi bi-telephone-fill" aria-hidden="true"></i>
                <h2>Phone</h2>
                <p>+1 (555) 123-4567<br />+1 (555) 987-6543</p>
              </div>

              <div className="contact-card">
                <i className="bi bi-envelope-fill" aria-hidden="true"></i>
                <h2>Email</h2>
                <p>hello@buildpulse.com<br />support@buildpulse.com</p>
              </div>

              <div className="contact-card">
                <i className="bi bi-geo-alt-fill" aria-hidden="true"></i>
                <h2>Address</h2>
                <p>123 Construction Avenue<br />New York, NY 10001</p>
              </div>
            </div>

            {/* Form + Map */}
            <div className="contact-grid">
              {/* Form */}
              <div className="form-wrapper" id="contact-form">
                <h2>Send a Message</h2>
                <p>Fill out the form and we'll get back to you within 24 hours.</p>

                {submitted ? (
                  <div className="success-message">
                    <i className="bi bi-check-circle-fill" aria-hidden="true"></i>
                    <h3>Message Sent!</h3>
                    <p>Thanks for reaching out. We'll respond shortly.</p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit}>
                    <div className="form-group">
                      <label htmlFor="contact-name" className="visually-hidden">Your Name</label>
                      <input
                        id="contact-name"
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="Your Name"
                        required
                      />
                    </div>

                    <div className="form-group">
                      <label htmlFor="contact-email" className="visually-hidden">Email Address</label>
                      <input
                        id="contact-email"
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="Email Address"
                        required
                      />
                    </div>

                    <div className="form-group">
                      <label htmlFor="contact-phone" className="visually-hidden">Phone Number</label>
                      <input
                        id="contact-phone"
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        placeholder="Phone Number"
                      />
                    </div>

                    <div className="form-group">
                      <label htmlFor="contact-message" className="visually-hidden">Your Message</label>
                      <textarea
                        id="contact-message"
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        placeholder="Your Message"
                        required
                      />
                    </div>

                    <button type="submit" className="submit-btn" disabled={loading}>
                      {loading ? (
                        <>
                          <span className="spinner" aria-hidden="true"></span>
                          Sending...
                        </>
                      ) : (
                        <>
                          <i className="bi bi-send-fill" aria-hidden="true"></i>
                          Send Message
                        </>
                      )}
                    </button>
                  </form>
                )}
              </div>

              {/* Map */}
              <div className="map-wrapper">
                <iframe
                  title="Office Location"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3024.2219901290355!2d-74.00369368400567!3d40.71312937932772!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a316bb7e0d5%3A0xb89d1fe6bc499443!2sDowntown%20Conference%20Center!5e0!3m2!1sen!2sus!4v1644262071856!5m2!1sen!2sus"
                  allowFullScreen
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </div>
      </main>
    </>
  );
};

export default ContactUs;