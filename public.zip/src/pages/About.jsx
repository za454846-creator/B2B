import React from "react";
import { Helmet } from "react-helmet-async";

import StatsSection from "../components/Home_components/StatsSection";
import Testimonials from "../components/Home_components/Testimonials";
import CTASection from "../components/Home_components/CTASection";
import FaqComponent from "../components/Home_components/FaqComponent";

import "../assets/css/about.css";
import "../assets/css/style.css";

import storyImg from "../assets/Images/about_pageimage.svg";
import teamImg1 from "../assets/Images/marcus.webp";
import teamImg2 from "../assets/Images/elena.webp";
import teamImg3 from "../assets/Images/jordan.webp";
import teamImg4 from "../assets/Images/nicholas.webp";


const PAGE_URL = '/about';
const PAGE_TITLE = 'About Bid Connectors';
const PAGE_DESCRIPTION =
  'Bid Connectors is a leading platform to explore construction projects in the US and bid on them before your competitors. We help contractors find projects effortlessly.';

const aboutFaqs = [
  {
    question: "Is Bid Connectors a software company or a construction company?",
    answer: "Software, full stop. We don't bid on projects ourselves, hold any GC or subcontractor license, or compete with our own users for work.",
  },
  {
    question: "Where is the team based?",
    answer: "Fully remote, anchored around Columbus, Ohio, with people spread across six states — most of whom came from construction or a construction-adjacent career before this.",
  },
];

const aboutTestimonials = [
  {
    quote:
      "I called their support line at 7 AM before a bid was due, expecting a ticket number back. Got a guy who used to run field estimates himself, and he knew exactly what I was asking.",
    name: "Renee Castillo",
    title: "Owner, Castillo Concrete & Sitework",
  },
  {
    quote:
      "Most software built for contractors is made by people who've never set foot on a jobsite. Five minutes into using this one, you can tell that isn't true here.",
    name: "Marcus Delaney",
    title: "Preconstruction Manager, Delaney Bros. Construction",
  },
  {
    quote:
      "They told me flat out that a plan I wanted wouldn't help my trade. Cost them a sale that day. Earned my renewal every year since.",
    name: "Wendy Ip",
    title: "Principal, Ip Mechanical Group",
  },
];

function About() {
  return (
    <>
      <Helmet>
        <title>{PAGE_TITLE}</title>
        <meta name="description" content={PAGE_DESCRIPTION} />
        <link rel="canonical" href={PAGE_URL} />

        {/* Open Graph */}
        <meta property="og:type" content="website" />
        <meta property="og:title" content={PAGE_TITLE} />
        <meta property="og:description" content={PAGE_DESCRIPTION} />
        <meta property="og:url" content={PAGE_URL} />

        {/* Twitter Card */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={PAGE_TITLE} />
        <meta name="twitter:description" content={PAGE_DESCRIPTION} />
      </Helmet>

      <main>
        {/* ================= BANNER SECTION ================= */}
        <section className="about-banner">
          <div className="container">
            <div className="banner-content">

              <h1>
                Built By People Who Used to <span>Chase Bids the Hard Way</span>
              </h1>

              <p>
                Three estimators, a shared spreadsheet, and about forty browser
                tabs a day, that's genuinely how this started, not in a pitch
                deck. We got sick of losing entire mornings to public bid
                boards that looked like they hadn't been touched since 2009,
                so we built the tool we wished someone else had already made.
              </p>

              <a href="https://bidconnectors.com/bidconnectors/register" className="banner-btn" target="_blank" rel="noopener noreferrer">
                Meet the Team <i className="bi bi-arrow-right"></i>
              </a>

            </div>
          </div>
        </section>

        {/* ================= STATS SECTION ================= */}
   <StatsSection
  stats={[
    { value: '2021', label: 'Year Bid Connectors Opened For Business' },
    { value: '41', label: 'Cities Our Founding Team Bid Work' },
    { value: '6.2 hrs', label: 'Avg. Weekly Search Time Cut For Early Users' },
    { value: '112', label: 'Data Sources Checked Each Morning' },
  ]}
/>

        {/* ================= OUR STORY SECTION ================= */}
        <section className="our-story-sec">
          <div className="container">
            <div className="row align-items-center">

              <div className="col-lg-6 col-md-6 col-12 mb-4 mb-md-0">
                <div className="left_content">

                  <h2>It Started With a Frustrated Estimator, Not a Business Plan</h2>

                  <p>
                    Marcus Webb spent nine years estimating electrical work
                    for a mid-size general contractor in Ohio. Twice a week,
                    more or less, he'd burn a whole morning cross-referencing
                    five county procurement sites, one state portal, and a
                    handful of private plan rooms just to land on three
                    projects actually worth bidding.
                  </p>
                  <p>
                    He wasn't the only one doing this. The first version of
                    Bid Connectors matched exactly one trade, in exactly one
                    state. It wasn't much to look at. Four contractors asked
                    to pay for it anyway, before there was even a pricing
                    page to send them.
                  </p>

                </div>
              </div>

              <div className="col-lg-6 col-md-6 col-12">
                <div className="right_col">

                  <img src={storyImg} alt="Bid Connectors team reviewing project data" />

                  <div className="stats-wrapper">

                    <div className="stat-box">
                      <p>FOUNDED</p>
                      <h3>2007</h3>
                    </div>

                    <div className="divider"></div>

                    <div className="stat-box">
                      <p>HEADQUARTERS</p>
                      <h3>Columbus, OH</h3>
                    </div>

                    <div className="divider"></div>

                    <div className="stat-box">
                      <p>ACCOUNTS SERVED</p>
                      <h3 className="highlight">7,400+</h3>
                    </div>

                  </div>

                </div>
              </div>

            </div>
          </div>
        </section>

        {/* ================= MISSION & VISION ================= */}
        <section className="mission-vision-section">
          <div className="container">

            <div className="mission-vision-header text-center">
              <span className="about-badge">Why We Exist</span>
            </div>

            <div className="row g-4 mission-vision-grid">

              <div className="col-lg-6 col-md-6">
                <div className="mission-vision-card h-100">
                  <div className="mission-vision-icon-wrap">
                    <i className="bi bi-bullseye"></i>
                  </div>
                  <h3>Our Mission</h3>
                  <p>
                    Give a five-person electrical outfit the same first look
                    at a project that a 500-person national contractor gets,
                    before the deadline makes it irrelevant.
                  </p>
                </div>
              </div>

              <div className="col-lg-6 col-md-6">
                <div className="mission-vision-card h-100">
                  <div className="mission-vision-icon-wrap">
                    <i className="bi bi-eye"></i>
                  </div>
                  <h3>Our Vision</h3>
                  <p>
                    A construction industry where finding a relevant project
                    takes minutes, not a decade of relationships and a
                    rolodex of city clerks.
                  </p>
                </div>
              </div>

            </div>

          </div>
        </section>

        {/* ================= CORE VALUES ================= */}
        <section className="core-values-section">
          <div className="container">

            <div className="text-center mb-5">
              <span className="about-badge">OUR CORE VALUES</span>
              <h2 className="values-title">We Stand Out For A Reason</h2>
              <p className="values-subtitle">
                None of this is printed on a poster in some offices. We
                don't have an office. But every product decision gets run
                through these three filters.
              </p>
            </div>

            <div className="row g-4">

              <div className="col-lg-4 col-md-6">
                <div className="value-card">
                  <h3>Ship the Useful Version First</h3>
                  <p>
                    A filter that works for 80% of trades today beats a
                    perfect one that ships next quarter. We'd rather hear
                    what's broken from real bidders.
                  </p>
                </div>
              </div>

              <div className="col-lg-4 col-md-6">
                <div className="value-card">
                  <h3>Say the Boring Part Out Loud</h3>
                  <p>
                    If a data source updates weekly instead of daily, we say
                    so on the page. If a plan caps out at 300 takeoff pages
                    a month, that's not a footnote.
                  </p>
                </div>
              </div>

              <div className="col-lg-4 col-md-6">
                <div className="value-card">
                  <h3>No Decisions Without a Field Person in the Room</h3>
                  <p>
                    Every major feature gets reviewed by someone who has
                    actually estimated a bid.
                  </p>
                </div>
              </div>

            </div>

          </div>
        </section>

        {/* ================= PROCESS ================= */}
        <section className="process-section">
          <div className="container">

            <div className="text-center">
              <span className="about-badge">BEHIND THE SCENES</span>
              <h2 className="section-title">How a Notice Becomes a Bid-Ready Package</h2>
              <p className="section-desc">
                Four steps happen before a project ever lands in your feed.
              </p>
            </div>

            <div className="row process-grid">

              {[
                { id: 1, title: "Capture", desc: "Scanners check agency portals, plan rooms, and developer filings every few hours, not once a week." },
                { id: 2, title: "Qualify", desc: "Each listing gets scored against your trade, location, and typical contract size before it ever reaches your account." },
                { id: 3, title: "Assemble", desc: "Plans, specs, and addenda get bundled into one package instead of five separate downloads." },
                { id: 4, title: "Deliver", desc: "It lands in your queue, usually the same day it's published, often before a competitor has even opened the agency's site." }
              ].map((item) => (
                <div key={item.id} className="col-lg-3 col-md-6 col-sm-12">
                  <div className="process-step">
                    <span>{String(item.id).padStart(2, '0')}</span>
                    <h3>{item.title}</h3>
                    <p>{item.desc}</p>
                  </div>
                </div>
              ))}

            </div>

          </div>
        </section>

        {/* ================= TEAM ================= */}
        {/*
          NOTE: all four cards below currently use the SAME placeholder
          image (teamImg). Replace per-card with each person's real
          photo when available.
        */}
        <section className="team-section" id="team">
          <div className="container">

            <h2 className="section-title">The Four People Most Likely to Answer Your Support Email</h2>

            <div className="team-grid">

              <div className="team-card">
                <img src={teamImg1} alt="Marcus Webb" className="team-img" />
                <h3>Marcus Webb</h3>
                <p className="role">Co-Founder, Head of Product — former Chief Estimator, 9 years</p>
              </div>

              <div className="team-card">
                <img src={teamImg2} alt="Elena Torres" className="team-img" />
                <h3>Elena Torres</h3>
                <p className="role">Co-Founder, Engineering Lead</p>
              </div>

              <div className="team-card">
                <img src={teamImg3} alt="Jordan Pike" className="team-img" />
                <h3>Jordan Pike</h3>
                <p className="role">Field Advisor — 15 years as a GC superintendent</p>
              </div>

              <div className="team-card">
                <img src={teamImg4} alt="Nicholas A. Davis" className="team-img" />
                <h3>Nicholas A. Davis</h3>
                <p className="role">Customer Success Lead</p>
              </div>

            </div>

          </div>
        </section>

        {/* ================= TESTIMONIALS ================= */}
        <Testimonials
          badge="TESTIMONIALS"
          heading="Why Contractors Trust Us"
          highlight="With Their Morning Routine"
          subtitle="Real feedback from the people who use Bid Connectors every day."
          testimonials={aboutTestimonials}
        />

        {/* ================= FAQ ================= */}
        <FaqComponent
          title="Quick Answers"
          highlight="About Us"
          description="Before you ask — a few things worth knowing up front."
          faqs={aboutFaqs}
        />

        {/* ================= CTA ================= */}
        <CTASection
          titleLine1="We Built the Tool We Couldn't Find."
          titleHighlight="Try the One We Ended Up With."
          subText="No sales call required to see what's currently open in your trade and area."
          primaryBtnText="See Open Projects"
        primaryBtnLink="https://bidconnectors.com/bidconnectors/register"
  primaryBtnNewTab={true}
  secondaryBtnText="Talk to Sales"
  secondaryBtnLink="https://bidconnectors.com/bidconnectors/register"
  secondaryBtnNewTab={true}
  noteText="No credit card · Free forever plan · Cancel anytime"
        />
      </main>
    </>
  );
}

export default About;