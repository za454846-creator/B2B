import { Routes, Route } from "react-router-dom";
import { HelmetProvider, Helmet } from "react-helmet-async";

import Home from "./pages/Home";
import About from "./pages/About";
import ContactUs from "./pages/ContactUs";
import Pricing from "./pages/Pricing";
import Subcontractors from "./pages/Subcontractors";
import Navbar from "./components/Mainlayout/Navbar";
import Buildingproductmanufctures from "./pages/Buildingproductmanufctures";
import Faq from "./pages/Faq";
import Footer from "./components/Mainlayout/Footer";

/*
  SEO FIXES IN THIS VERSION:
  - Wrapped everything in <HelmetProvider> — required for the
    per-page <Helmet> tags (title/description/OG tags) added on
    individual pages to actually take effect. Without this, those
    tags silently do nothing.
  - Added a site-wide default <Helmet> here with a title template
    (so every page's title automatically gets " | Bid Connectors"
    appended unless a page sets its own full title) and a fallback
    meta description — this covers any page that doesn't set its own
    Helmet yet.
  - Fixed two routes that were missing their leading "/"
    ("solutions/subcontractors" and
    "solutions/buildingproductmanufctures"). Without the leading
    slash, React Router treats these as RELATIVE paths — they'd
    resolve differently (and break) depending on what URL the user
    was already on. This also produced inconsistent internal links,
    which hurts SEO crawling/indexing.
  - Renamed the Building Product Manufacturers URL from the typo'd,
    unreadable "buildingproductmanufctures" to the hyphenated
    "building-product-manufacturers". Hyphenated, correctly-spelled
    slugs are a standard SEO best practice (readable in search
    results, easier for search engines to parse as separate words).
    The OLD url now redirects to the new one with a <Navigate replace>
    so old links / already-indexed pages don't just 404.
  - Added a catch-all 404 route with <meta name="robots"
    content="noindex"> — without this, unknown URLs would render
    nothing but still return a 200 OK status, which search engines
    treat as a "soft 404" and can hurt overall site SEO. Add your own
    NotFound page component's content inside it.
*/

function DefaultSEO() {
  return (
    <Helmet
      titleTemplate="%s | Bid Connectors"
      defaultTitle="Find Latest Construction Projects Faster And Win 95% Of Your Bids"
    >
      <meta
        name="description"
        content="Explore one of the biggest repositories for construction projects in the US and start bidding before others. Get expert insights from Bid Connector experts now!"
      />
      <meta name="robots" content="index, follow" />
    </Helmet>
  );
}

function NotFound() {
  return (
    <>
      <Helmet>
        <title>Page Not Found</title>
        <meta name="robots" content="noindex, follow" />
      </Helmet>
      <div className="container py-5 text-center">
        <h1>404 — Page Not Found</h1>
        <p>The page you're looking for doesn't exist or has moved.</p>
      </div>
    </>
  );
}

function App() {
  return (
    <HelmetProvider>
      <DefaultSEO />
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/solutions/subcontractors" element={<Subcontractors />} />
        <Route
          path="/solutions/building-product-manufacturers"
          element={<Buildingproductmanufctures />}
        />
        <Route path="/faq" element={<Faq />} />
        <Route path="/contact-us" element={<ContactUs />} />
        <Route path="/pricing" element={<Pricing />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
      <Footer />
    </HelmetProvider>
  );
}

export default App;