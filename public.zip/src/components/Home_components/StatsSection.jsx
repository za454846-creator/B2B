import React from 'react';
import '../../assets/css/home.css';
import '../../assets/css/style.css';

/**
 * Reusable Stats Section
 * Design/layout hamesha same rahega, sirf `stats` prop se content change hoga.
 *
 * Usage:
 * <StatsSection stats={[
 *   { value: '60,000+', label: 'ACTIVE PROJECTS' },
 *   { value: '9,200+', label: 'CONTRACTORS' },
 *   { value: '34%', label: 'AVG WIN RATE' },
 *   { value: '$2B', label: 'PROJECTS VALUE TRACKED' },
 * ]} />
 */

const defaultStats = [
  { value: '60,000+', label: 'ACTIVE PROJECTS' },
  { value: '9,200+', label: 'CONTRACTORS' },
  { value: '34%', label: 'AVG WIN RATE' },
  { value: '$2B', label: 'PROJECTS VALUE TRACKED' },
];

const StatsSection = ({ stats = defaultStats }) => {
  return (
    <div className="stats-section py-5">
      <div className="container">
        <div className="row g-4">
          {stats.map((stat, index) => (
            <div className="col-md-3" key={index}>
              <div className="simple-stat-card">
                <h3>{stat.value}</h3>
                <p>{stat.label}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StatsSection;