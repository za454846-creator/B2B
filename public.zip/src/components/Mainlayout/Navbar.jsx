import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import "../../assets/css/navbar.css";

const Navbar = () => {

  const [isOpen, setIsOpen] = useState(false);
  const [theme, setTheme] = useState(
    localStorage.getItem("theme") || "dark"
  );
  const [scrolled, setScrolled] = useState(false);
  const [solutionsOpen, setSolutionsOpen] = useState(false);

  const location = useLocation();

  const menuItems = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    {
      name: 'Solutions',
      path: '/solutions',
      dropdown: [
        { name: 'Subcontractors', path: 'solutions/subcontractors' },
        { name: 'Building Product Manufacturers', path: 'solutions/building-product-manufacturers' },
      ],
    },
    { name: 'Faq', path: '/faq' },
    { name: 'Contact Us', path: '/contact-us' },
    { name: 'Pricing', path: '/pricing' },
  ];

  useEffect(() => {
    document.body.className = theme;
    localStorage.setItem("theme", theme);
  }, [theme]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = isOpen ? "hidden" : "unset";
  }, [isOpen]);

  const toggleTheme = () => {
    setTheme(prev => (prev === "light" ? "dark" : "light"));
  };

  const closeMenu = () => {
    setIsOpen(false);
    setSolutionsOpen(false);
  };

  return (
    <header>
      <nav className={`navbar navbar-expand-lg bp-nav ${scrolled ? "bp-scrolled" : ""}`}>
        <div className="bp-container d-flex align-items-center justify-content-between w-100">

          <Link to="/" className="navbar-brand bp-brand" onClick={closeMenu}>
            Bid <span>Connectors</span>
          </Link>

          <button
            className="navbar-toggler"
            onClick={() => setIsOpen(!isOpen)}
          >
            ☰
          </button>

          {isOpen && (
            <div className="bp-overlay" onClick={closeMenu} />
          )}

          <div className={`navbar-collapse ${isOpen ? "mobile-show" : ""}`}>

            <button className="bp-close" onClick={closeMenu}>
              ✕
            </button>

            <ul className="navbar-nav mx-auto">
              {menuItems.map(item => (
                item.dropdown ? (
                  <li
                    className="nav-item bp-dropdown"
                    key={item.name}
                    onMouseEnter={() => setSolutionsOpen(true)}
                    onMouseLeave={() => setSolutionsOpen(false)}
                  >
                    <span
                      className={`nav-link bp-link bp-dropdown-toggle ${location.pathname.startsWith(item.path) ? "active" : ""}`}
                      onClick={() => setSolutionsOpen(prev => !prev)}
                      role="button"
                    >
                      {item.name}
                      <i className={`bi bi-chevron-down bp-caret ${solutionsOpen ? "bp-caret-open" : ""}`}></i>
                    </span>

                    <ul className={`bp-dropdown-menu ${solutionsOpen ? "bp-dropdown-menu-open" : ""}`}>
                      {item.dropdown.map(sub => (
                        <li key={sub.name}>
                          <Link
                            to={sub.path}
                            className={`bp-dropdown-link ${location.pathname === sub.path ? "active" : ""}`}
                            onClick={closeMenu}
                          >
                            {sub.name}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </li>
                ) : (
                  <li className="nav-item" key={item.name}>
                    <Link
                      to={item.path}
                      className={`nav-link bp-link ${location.pathname === item.path ? "active" : ""}`}
                      onClick={closeMenu}
                    >
                      {item.name}
                    </Link>
                  </li>
                )
              ))}
            </ul>

            <div className="mobile-buttons d-flex align-items-center gap-2">

              <button onClick={toggleTheme} className="btn btn-sm">
                {theme === "dark" ? "☀️" : "🌙"}
              </button>

              <a
                className="btn btn-signin"
                href="https://bidconnectors.com/bidconnectors/login"
                target="_blank"
                rel="noopener noreferrer"
              >
                Sign In
              </a>

              <Link
                to="/pricing"
                className="btn btn-startfree"
                onClick={closeMenu}
              >
                Start Free
              </Link>

            </div>

          </div>

        </div>
      </nav>
    </header>
  );
};

export default Navbar;